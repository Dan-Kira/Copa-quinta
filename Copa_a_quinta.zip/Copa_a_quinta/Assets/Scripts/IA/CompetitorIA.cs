using System.Collections;
using UnityEngine;

public class CompetitorIA : MonoBehaviour
{
    [Header("Velocidade")]
    [SerializeField] private float velocidadeMin = 6f;
    [SerializeField] private float velocidadeMax = 12f;
    [SerializeField] private float velocidadeBase = 9f;
    private float currentSpeed;

    [Header("Pulo")]
    [SerializeField] private float jumpForce = 12f;
    [SerializeField] private Transform groundCheck;
    [SerializeField] private LayerMask groundLayer;
    [SerializeField] private float groundCheckRadius = 0.1f;

    [Header("Detecção")]
    [SerializeField] private float wallCheckDistance = 1f;
    [SerializeField] private float groundCheckDistance = 1.5f;
    [SerializeField] private float waypointReachDistance = 3f;

    [Header("Grappling Hook")]
    [SerializeField] private ControleHabilidadeJogador grapplingHook;
    [SerializeField] private float tempoMaxNoGancho = 1.5f;
    [SerializeField] private float alturaMinParaUsar = 1.5f;
    private bool estaNoGancho;
    private float timerGancho;

    [Header("Agarrão")]
    [SerializeField] private float alcanceAgarrao = 2f;
    [SerializeField] private float forcaAgarrao = 10f;
    [SerializeField] private float cooldownAgarrao = 3f;
    [SerializeField] private LayerMask camadaCompetidor;
    private float timerAgarrao;

    private bool jumpRequested;
    private bool isGrounded;

    [Header("Movimento")]
    public Transform[] waypoints;
    private int currentWaypoint;

    public Transform playerTransform1;
    public Transform playerTransform2;
    private float currentDistance;
    [SerializeField] private float maxPlayerDistance;
    private Rigidbody2D rb;

    [Header("Interagir")]
    public Timer internalTimer;
    private SpawnsData currentSpawn;
    public SpawnController initialSpawn;
    public GameFinish gameFinish;

    public LayerMask spawnsLayer;


    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();

        if (currentSpawn == null)
        {
            currentSpawn = initialSpawn.spawnData;
        }

        if (gameFinish == null)
        {
            gameFinish = FindAnyObjectByType<GameFinish>();
        }
    }

    void Update()
    {
        isGrounded = Physics2D.OverlapCircle(groundCheck.position, groundCheckRadius, groundLayer);
    }

    void FixedUpdate()
    {
        if (waypoints == null || waypoints.Length == 0)
            return;

        DefinirVelocidade();
        MovementToWaypoint();
        AtualizarGancho();
        AtualizarAgarrao();

        if (jumpRequested)
                TryToJump();
    }

    public void DefinirVelocidade()
    {
        if (playerTransform2 == null)
        {
            currentDistance = transform.position.x - playerTransform1.position.x;
        }
        else
        {
            currentDistance = transform.position.x - (playerTransform1.position.x + playerTransform2.position.x) / 2f;
        }

        if (currentDistance >= maxPlayerDistance)
        {
            currentSpeed = velocidadeMin;
        }
        else if (currentDistance >= -maxPlayerDistance)
        {
            currentSpeed = velocidadeMax;
        }
        else
        {
            currentSpeed = velocidadeBase;
        }
    }

    public void MovementToWaypoint()
    {

        Transform target = waypoints[currentWaypoint];

        Vector2 direction = ((Vector2)target.position - rb.position).normalized;

        float velocityX = direction.x * currentSpeed;

        rb.linearVelocity = new Vector2(velocityX, rb.linearVelocity.y);

        if (isGrounded)
        {
            if (HasWallAhead())
            {
                jumpRequested = true;
            }

            if (HasGapAhead() && target.position.y >= transform.position.y - 0.5f)
            {
                jumpRequested = true;
            }
        }

        CheckWaypointProgress();
    }

    public void CheckWaypointProgress()
    {
        Transform target = waypoints[currentWaypoint];

        float distance = Vector2.Distance(transform.position, target.position);

        if (distance <= waypointReachDistance)
        {
            currentWaypoint = (currentWaypoint + 1) % waypoints.Length;
        }
    }

    private float GetMoveDirection()
    {
        Transform target = waypoints[currentWaypoint];

        return target.position.x > transform.position.x ? 1f : -1f;
    }

    public bool HasWallAhead()
    {
        Vector2 direction = Vector2.right * GetMoveDirection();

        RaycastHit2D hit = Physics2D.Raycast(transform.position, direction, wallCheckDistance, groundLayer);

        return hit.collider != null;
    }

    public bool HasGapAhead()
    {
        float moveDirection = GetMoveDirection();

        Vector2 rayOrigin = (Vector2)transform.position + Vector2.right * moveDirection;

        RaycastHit2D hit = Physics2D.Raycast(rayOrigin, Vector2.down, groundCheckDistance, groundLayer);

        return hit.collider == null;
    }

    public void TryToJump()
    {
        if (!jumpRequested || estaNoGancho)
            return;

        rb.linearVelocity = new Vector2(rb.linearVelocity.x, jumpForce);
        jumpRequested = false;
    }

    private void AtualizarGancho()
    {
        if(grapplingHook == null)
            return;

        if (!estaNoGancho)
        {
            Transform alvo = waypoints[currentWaypoint];
            bool ganchoDisponivel = grapplingHook.PodeUsarHabilidade;
            bool wayPointEstaAcima = alvo.position.y > transform.position.y + alturaMinParaUsar;

            if(ganchoDisponivel && wayPointEstaAcima)
            {
                grapplingHook.AtivarGancho();
                estaNoGancho = true;
                timerGancho = 0f;
                jumpRequested = false;
            }
        }
        else
        {
            timerGancho += Time.fixedDeltaTime;

            bool wayPointAlcancado = Vector2.Distance(transform.position, waypoints[currentWaypoint].position) <= waypointReachDistance;
            bool tempoEsgotado = timerGancho >= tempoMaxNoGancho;

            if (wayPointAlcancado || tempoEsgotado)
            {
                grapplingHook.DesativarGancho();
                estaNoGancho = false;
            }
        }
    }

    private void AtualizarAgarrao()
    {
        timerAgarrao -= Time.fixedDeltaTime;

        if(timerAgarrao > 0f)
            return;

        timerAgarrao = cooldownAgarrao;

        Vector2 direcao = Vector2.right * GetMoveDirection();
        RaycastHit2D hit = Physics2D.Raycast(transform.position, direcao, alcanceAgarrao, camadaCompetidor);

        if (hit.collider == null)
        return;

        Rigidbody2D rbAlvo = hit.collider.GetComponent<Rigidbody2D>();

        if (rbAlvo == null)
        return;

        Vector2 direcaoEmpurrao = ((Vector2)hit.collider.transform.position - (Vector2)transform.position).normalized;
        rbAlvo.AddForce(direcaoEmpurrao * forcaAgarrao, ForceMode2D.Impulse);
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("SpawnPoint"))
        {
            DefineSpawn();
        }
        else if (collision.CompareTag("DeathPoint"))
        {
            DeathRoutine();
        }
        else if (collision.CompareTag("WinningPoint"))
        {
            WinGame();
        }
    }

    public void DefineSpawn()
    {
        if (!internalTimer.isUnder3Min)
        {
            currentSpawn = initialSpawn.spawnData;
            return;
        }

        Collider2D spawnReached = Physics2D.OverlapCircle(transform.position, 2f, spawnsLayer);

        if (spawnReached == null)
            return;

        SpawnController spawn = spawnReached.GetComponent<SpawnController>();

        if (spawn == null)
            return;

        if (spawn.name != currentSpawn.name)
        {
            currentSpawn = spawn.spawnData;

            Debug.Log("Novo spawn alcançado: " + spawn.name);
        }
    }

    public void DeathRoutine()
    {
        rb.linearVelocity = Vector2.zero;

        transform.position = new Vector3(currentSpawn.positionX, currentSpawn.positionY, currentSpawn.positionZ);
    }

    public void WinGame()
    {
        gameFinish.ArmazenateInfos(internalTimer.currentTime, gameObject.name);

        StartCoroutine(VictoryRoutine());
    }

    IEnumerator VictoryRoutine()
    {
        yield return null;

        gameObject.SetActive(false);
    }
}