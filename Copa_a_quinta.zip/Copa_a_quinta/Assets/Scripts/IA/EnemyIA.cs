using UnityEngine;

public class EnemyIA : MonoBehaviour
{
    [Header("Referências")]
    public AdaptationControl adaptationControl;
    public Transform[] waypoints;
    public Rigidbody2D rb;
    public Transform playerTransform;

    [Header("Modo Manual")]
    public bool useManualLevel = false;
    public AdaptationControl.NivelIA manualLevel = AdaptationControl.NivelIA.Iniciante;

    private readonly float[] speedByLevel = { 4f, 6f, 8f, 9.5f, 11f };
    private readonly float[] mistakeChanceByLevel = {  0.6f, 0.4f, 0.25f, 0.1f, 0.02f};
    private readonly float[] mistakeDurationByLevel = { 1.2f, 0.9f, 0.6f, 0.35f, 0.1f };
    private readonly float[] mistakeStrengthByLevel = {  3f, 2.5f, 1.8f, 1f, 0.4f };
    private readonly float[] reactionDelayByLevel = {  0.8f, 0.6f, 0.4f, 0.2f, 0.05f};

    [Header("Rubber Band (trava de distância)")]
    public float maxLeadDistance = 8f;
    [Range(0f, 0.5f)]
    public float brakeFactor = 0.25f;

    [Header("Janelas de Respiro")]
    public float breathingInterval = 20f;
    public float breathingDuration = 4f;

    private float breathingTimer = 0f;
    private bool isBreathing = false;
    private float breathingElapsed = 0f;

    private int currentWaypoint = 0;
    private float baseSpeed;
    private float currentSpeed;

    private bool isMakingMistake  = false;
    private float mistakeTimer = 0f;
    private float mistakeDirection = 0f;
    private bool mistakeIsHesitation;

    private float reactionTimer = 0f;
    private bool reactionReady = true;

    private int LevelIndex => useManualLevel ? (int)manualLevel : (adaptationControl != null ? (int)adaptationControl.nivelApropriado : 0);


    void Start()
    {
        if (waypoints == null || waypoints.Length == 0)
            Debug.LogWarning("[EnemyIA] Nenhum waypoint atribuído!");

        if (!useManualLevel && adaptationControl == null)
            Debug.LogWarning("[EnemyIA] useManualLevel está desativado mas AdaptationControl não foi atribuído!");

        baseSpeed = speedByLevel[LevelIndex];
        currentSpeed = baseSpeed;
        breathingTimer = breathingInterval;
    }

    void Update()
    {
        HandleReactionDelay();
        HandleBreathingWindow();
        HandleMistake();
        ApplyRubberBandBrake();
        MoveToWaypoint();
    }

    void HandleReactionDelay()
    {
        if (reactionReady) return;
        reactionTimer -= Time.deltaTime;
        if (reactionTimer <= 0f) reactionReady = true;
    }

    void TriggerReaction()
    {
        reactionReady = false;
        reactionTimer = reactionDelayByLevel[LevelIndex];
    }

    void HandleBreathingWindow()
    {
        if (!isBreathing)
        {
            breathingTimer -= Time.deltaTime;
            if (breathingTimer <= 0f)
            {
                isBreathing = true;
                breathingElapsed = 0f;
            }
        }
        else
        {
            breathingElapsed += Time.deltaTime;
            if (breathingElapsed >= breathingDuration)
            {
                isBreathing = false;
                breathingTimer = breathingInterval;
            }
        }
    }

    void HandleMistake()
    {
        if (isMakingMistake)
        {
            mistakeTimer -= Time.deltaTime;
            if (mistakeTimer <= 0f)
            {
                isMakingMistake = false;
                currentSpeed = baseSpeed;
            }
            else if (!mistakeIsHesitation)
            {
                rb.linearVelocity += new Vector2(mistakeDirection * mistakeStrengthByLevel[LevelIndex], 0f) * Time.deltaTime;
            }
            return;
        }

        float chance = mistakeChanceByLevel[LevelIndex] * (isBreathing ? 3f : 1f);

        if (Random.value < chance * Time.deltaTime)
        {
            isMakingMistake = true;
            mistakeTimer = mistakeDurationByLevel[LevelIndex] * (isBreathing ? 1.5f : 1f);
            mistakeIsHesitation = Random.value > 0.5f;
            TriggerReaction();

            if (mistakeIsHesitation)
                currentSpeed = baseSpeed * 0.45f;
            else
                mistakeDirection = Random.value > 0.5f ? 1f : -1f;
        }
    }

    void ApplyRubberBandBrake()
    {
        if (playerTransform == null || isMakingMistake) return;

        float distX = transform.position.x - playerTransform.position.x;

        if (distX > maxLeadDistance)
        {
            float excess = distX - maxLeadDistance;
            float brakeAmount = Mathf.Clamp01(excess / maxLeadDistance) * brakeFactor;
            currentSpeed = baseSpeed * (1f - brakeAmount);
        }
        else
        {
            if (!isMakingMistake)
                currentSpeed = baseSpeed;
        }
    }

    void MoveToWaypoint()
    {
        if (waypoints == null || waypoints.Length == 0) return;
        if (!reactionReady) return;

        Transform target = waypoints[currentWaypoint];
        Vector2 direction = ((Vector2)target.position - rb.position).normalized;

        rb.linearVelocity = direction * currentSpeed;

        if (Vector2.Distance(rb.position, target.position) < 0.5f)
        {
            currentWaypoint = (currentWaypoint + 1) % waypoints.Length;
            TriggerReaction();
        }
    }
}