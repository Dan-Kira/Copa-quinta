using UnityEngine;

public class AdaptationControl : MonoBehaviour
{
    public enum NivelIA
    {
        Iniciante,
        Basico,
        Intermediario,
        Avancado,
        Profissional
    }
    public NivelIA nivelApropriado;

    [Header("Dados coletados (sessão atual)")]
    public int deathCount;
    public float timeCosted;
    public int playerCount = 1;

    [Header("Dados acumulados (entre fases)")]
    public int totalDeaths;
    public float totalTime;
    public int totalRuns;

    public int dificuldadeJogador;

    void Awake()
    {
        LoadData();
        DefineLevel();
    }

    public void SaveAndUpdate()
    {
        totalDeaths += deathCount;
        totalTime += timeCosted;
        totalRuns += playerCount;

        PlayerPrefs.SetInt("totalDeaths", totalDeaths);
        PlayerPrefs.SetFloat("totalTime", totalTime);
        PlayerPrefs.SetInt("totalRuns", totalRuns);
        PlayerPrefs.Save();

        DefineLevel();
    }

    void LoadData()
    {
        totalDeaths = PlayerPrefs.GetInt("totalDeaths", 0);
        totalTime = PlayerPrefs.GetFloat("totalTime", 0f);
        totalRuns = PlayerPrefs.GetInt("totalRuns", 1);
    }

    public void ResetData()
    {
        PlayerPrefs.DeleteAll();
        totalDeaths = 0; totalTime = 0f; totalRuns = 1;
        deathCount = 0; timeCosted = 0f;
        DefineLevel();
    }

    public void DefineLevel()
    {
        int d = totalDeaths + deathCount;
        float t = totalTime + timeCosted;
        int r = Mathf.Max(totalRuns, 1);

        dificuldadeJogador = Mathf.RoundToInt((d + t) / r);

        if (dificuldadeJogador <= 5) nivelApropriado = NivelIA.Profissional;
        else if (dificuldadeJogador > 5  && dificuldadeJogador <= 10) nivelApropriado = NivelIA.Avancado;
        else if (dificuldadeJogador > 10 && dificuldadeJogador <= 15) nivelApropriado = NivelIA.Intermediario;
        else if (dificuldadeJogador > 15 && dificuldadeJogador <= 20) nivelApropriado = NivelIA.Basico;
    }
}