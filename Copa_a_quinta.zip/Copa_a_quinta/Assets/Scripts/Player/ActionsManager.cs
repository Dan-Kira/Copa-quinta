using System.Collections;
using UnityEngine;

public class ActionsManager : MonoBehaviour
{
    [SerializeField] private int grabDistance;
    [SerializeField] private float grabForce = 8f;
    public LayerMask grabLayer;
    public KeyCode actionKey;
    public float actionCooldown;
    private float lastActionTime; 

    public PlayerController player;
    private bool isPunished;

    void Update()
    {
        if (Input.GetKeyDown(actionKey) && Time.time >= lastActionTime + actionCooldown)
        {
            Debug.Log("Tentando pegar algo...");

            TryToGrab();
        }
    }

    public void TryToGrab()
    {
        lastActionTime = Time.time;

        RaycastHit2D target = Physics2D.Raycast(transform.position, Vector2.right, grabDistance, grabLayer);

        if(target.collider == null)
        {
            if(!isPunished)
            {
                Debug.Log("Falha em pegar algo");

                StartCoroutine(FailedActionRoutine(3, 2.5f));
            }

            return;
        }

        if(target.collider.CompareTag("Competitor"))
        {
            Debug.Log("Competidor agarrado: " + target.transform.name);

            GrabCompetitor(target.transform);
        }
    }

    public void GrabCompetitor(Transform grabedObject)
    {

        if(!grabedObject.TryGetComponent(out Rigidbody2D targetRb))
        {
            return;
        }

        Vector2 pushDirection = (grabedObject.position.x > transform.position.x) ? Vector2.left : Vector2.right;

        targetRb.AddForce(pushDirection * grabForce, ForceMode2D.Impulse);

        player.rb.AddForce(Vector2.right * (grabForce / 2), ForceMode2D.Impulse);
    }

    public IEnumerator FailedActionRoutine(int speedPenalty, float duration)
    {        
        isPunished = true;

        float originalSpeed = player.moveSpeed;

        player.moveSpeed = Mathf.Max(0f, player.moveSpeed - speedPenalty);

        yield return new WaitForSeconds(duration);

        player.moveSpeed = originalSpeed;

        isPunished = false;
    }

    private void OnDrawGizmos()
    {
        RaycastHit2D hit = Physics2D.Raycast(transform.position, Vector2.right, grabDistance, grabLayer);

        if (hit.collider != null)
        {
            Gizmos.color = Color.red;
            Gizmos.DrawLine(transform.position, hit.point);
        }
        else
        {
            Gizmos.color = Color.green;
            Gizmos.DrawRay(transform.position, Vector2.right * grabDistance);
        }
    }
}