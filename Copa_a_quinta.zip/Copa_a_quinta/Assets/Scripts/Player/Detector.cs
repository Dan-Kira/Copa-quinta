using UnityEngine;

[RequireComponent(typeof(CircleCollider2D))]
public class Detector : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.TryGetComponent(out ControleHabilidadeJogador jogador))
        {
            jogador.LiberarHabilidade(transform);
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.TryGetComponent(out ControleHabilidadeJogador jogador))
        {
            jogador.RemoverHabilidade(transform);
        }
    }
}