using UnityEngine;

public class ControleHabilidadeJogador : MonoBehaviour
{
    [Header("Componentes de Física e Visual")]
    [SerializeField] private SpringJoint2D springJoint;
    [SerializeField] private LineRenderer lineRenderer;

    [Header("Estado Atual")]
    [SerializeField] private Transform pontoAlvoDisponivel;

    public bool PodeUsarHabilidade => pontoAlvoDisponivel != null;

    private bool estaBalancando;

    private Collider2D myCollider;
    public Collider2D[] collidersToIgnore;

    public KeyCode habilidadeKey;

    private void Awake()
    {
        if (springJoint != null)
        {
            springJoint.enabled = false;
        }

        if (lineRenderer != null)
        {
            lineRenderer.positionCount = 0;
        }

        
        myCollider = GetComponent<Collider2D>();

        for(int i = 0; i < collidersToIgnore.Length; i++)
        {
            Physics2D.IgnoreCollision(myCollider, collidersToIgnore[i], true);
        }
    }

    public void LiberarHabilidade(Transform ponto)
    {
        pontoAlvoDisponivel = ponto;
    }

    public void RemoverHabilidade(Transform ponto)
    {
        if (estaBalancando)
        {
            return;
        }

        if (pontoAlvoDisponivel == ponto)
        {
            pontoAlvoDisponivel = null;
        }
    }

    private void Update()
    {
        if (Input.GetKeyDown(habilidadeKey) && PodeUsarHabilidade && !estaBalancando)
        {
            IniciarBalanco();
        }

        if (Input.GetKeyUp(habilidadeKey) && estaBalancando)
        {
            PararBalanco();
        }

        if (estaBalancando)
        {
            DesenharCorda();
        }
    }

    private void IniciarBalanco()
    {
        if (pontoAlvoDisponivel == null)
        {
            return;
        }

        if (springJoint == null)
        {
            Debug.LogError($"SpringJoint2D não configurado em {name}");
            return;
        }

        if (lineRenderer == null)
        {
            Debug.LogError($"LineRenderer não configurado em {name}");
            return;
        }

        estaBalancando = true;

        springJoint.connectedAnchor = pontoAlvoDisponivel.position;
        springJoint.enabled = true;

        lineRenderer.positionCount = 2;
    }

    private void DesenharCorda()
    {
        if (pontoAlvoDisponivel == null)
        {
            PararBalanco();
            return;
        }

        lineRenderer.SetPosition(0, transform.position);
        lineRenderer.SetPosition(1, pontoAlvoDisponivel.position);
    }

    private void PararBalanco()
    {
        estaBalancando = false;

        if (springJoint != null)
        {
            springJoint.enabled = false;
        }

        if (lineRenderer != null)
        {
            lineRenderer.positionCount = 0;
        }
    }

    public void AtivarGancho()
    {
        IniciarBalanco();
    }

    public void DesativarGancho()
    {
        PararBalanco();
        pontoAlvoDisponivel = null;
    }
}