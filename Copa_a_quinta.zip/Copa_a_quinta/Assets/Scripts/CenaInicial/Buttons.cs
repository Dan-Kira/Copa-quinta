using UnityEngine;
using UnityEngine.SceneManagement;

public class Buttons : MonoBehaviour
{   
    public string nomeCenaSingleplayer;
    public string nomeCenaMultiplayer;
    public void SinglePlayerButton()
    {
        SceneManager.LoadScene(nomeCenaSingleplayer);
    }

    public void MultiPlayerButton()
    {
        SceneManager.LoadScene(nomeCenaMultiplayer);
    }
}
