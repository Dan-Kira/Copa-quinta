using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameFinish : MonoBehaviour
{
    public static GameFinish Instance;
    public static string LastRaceScene;

    public List<RaceResult> results = new List<RaceResult>();

    public int maxPlayers = 4;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;

        DontDestroyOnLoad(gameObject);
    }

    public void ArmazenateInfos(float scoreRecebido, string nomeRecebido)
    {
        RaceResult newResult = new RaceResult();

        newResult.playerName = nomeRecebido;
        newResult.score = scoreRecebido;

        results.Add(newResult);

        if(results.Count >= maxPlayers)
        {
            FinishRace();
        }
    }

    void FinishRace()
    {
        
        LastRaceScene = SceneManager.GetActiveScene().name;
        Debug.Log("Cena salva: " + LastRaceScene);

        results.Sort((a, b) => a.score.CompareTo(b.score));

        SceneManager.LoadScene(3);
    }

    public void ClearResults()
    {
        results.Clear();
    }
}