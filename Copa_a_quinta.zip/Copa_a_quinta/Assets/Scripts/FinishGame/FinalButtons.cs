using UnityEngine;
using UnityEngine.SceneManagement;

public class FinalButtons : MonoBehaviour
{    
    public void JogarNovamenteButton()
    {   
        GameFinish.Instance.ClearResults();

        SceneManager.LoadScene(GameFinish.LastRaceScene);
    }

    public void SairGameplayButton()
    {
        GameFinish.Instance.ClearResults();

        SceneManager.LoadScene(0);
    }
}
